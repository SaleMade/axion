// ZapVoice Nosso — INJETOR pro app de desktop (WhatsApp da Windows Store = WebView2)
// Conecta na porta de debug do WebView2 (CDP), injeta o WA-JS + o painel DENTRO
// do app, na propria pagina web.whatsapp.com que o app carrega. O atendente
// continua ligando e conversando no app, e ganha o soundboard do funil por dentro.
//
// Requisitos: Node 21+ (WebSocket nativo) e o app aberto com --remote-debugging-port
// (o start.ps1 cuida disso). Uso: node inject.js
'use strict';
const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');

const PORT = process.env.ZV_PORT ? Number(process.env.ZV_PORT) : 9222;
const MEDIA_PORT = process.env.ZV_MEDIA_PORT ? Number(process.env.ZV_MEDIA_PORT) : 9223;
const BASE_URL = process.env.ZV_CONFIG_URL || 'https://axion-api.axion-dash.workers.dev/api/salechat';
// Perfil: vendedores (padrao) ou cobradores. Vem de perfil.txt na pasta (o instalador
// de cobradores traz esse arquivo) ou da env ZV_PERFIL. Cada perfil tem config propria.
let PERFIL = (process.env.ZV_PERFIL || '').trim().toLowerCase();
if (!PERFIL) { try { PERFIL = require('fs').readFileSync(require('path').join(__dirname, 'perfil.txt'), 'utf8').trim().toLowerCase(); } catch (_) {} }
if (PERFIL !== 'cobradores') PERFIL = 'vendedores';
const CONFIG_URL = PERFIL === 'cobradores' ? (BASE_URL + '?perfil=cobradores') : BASE_URL;
const MEDIA_BASE = BASE_URL.replace(/\/+$/, '') + '/media';
const DIR = __dirname;

// Baixa bytes de uma URL (mídia do R2 servida pelo Worker). Node não tem CSP.
function fetchBytes(url) {
  return new Promise((resolve) => {
    let done = false; const fin = (v) => { if (!done) { done = true; resolve(v); } };
    try {
      const r = https.get(url, (res) => {
        if (res.statusCode !== 200) { res.resume(); return fin(null); }
        const chunks = []; res.on('data', (c) => chunks.push(c)); res.on('end', () => fin(Buffer.concat(chunks)));
      });
      r.on('error', () => fin(null));
      r.setTimeout(30000, () => { try { r.destroy(); } catch (_) {} fin(null); });
    } catch (_) { fin(null); }
  });
}

// Busca a config do Sale Chat na AXION (mensagens + funis que o Diretor edita
// na dash). Node nao tem CSP, entao busca aqui e injeta no painel. Falha -> null.
function fetchRemoteConfig() {
  return new Promise((resolve) => {
    let done = false; const fin = (v) => { if (!done) { done = true; resolve(v); } };
    try {
      const r = https.get(CONFIG_URL, (res) => {
        let d = ''; res.on('data', (c) => (d += c)); res.on('end', () => { try { fin(JSON.parse(d)); } catch (_) { fin(null); } });
      });
      r.on('error', () => fin(null));
      r.setTimeout(6000, () => { try { r.destroy(); } catch (_) {} fin(null); });
    } catch (_) { fin(null); }
  });
}

// ─── Auto-update do painel: puxa o codigo do painel/css do servidor (com fallback pro disco) ──
// Assim, quando o Diretor publica uma melhoria no painel, ela entra sozinha na maquina do
// atendente (sem rebaixar). A dash serve os arquivos em /sc-panel.js e /sc-panel.css.
const DASH_URL = (process.env.ZV_DASH_URL || 'https://axion.axion-dash.workers.dev').replace(/\/+$/, '');
const PANEL_JS_URL = DASH_URL + '/sc-panel.js';
const PANEL_CSS_URL = DASH_URL + '/sc-panel.css';
function fetchText(url) {
  return new Promise((resolve) => {
    let done = false; const fin = (v) => { if (!done) { done = true; resolve(v); } };
    try {
      const r = https.get(url, (res) => {
        if (res.statusCode !== 200) { res.resume(); return fin(null); }
        let d = ''; res.setEncoding('utf8'); res.on('data', (c) => (d += c)); res.on('end', () => fin(d));
      });
      r.on('error', () => fin(null));
      r.setTimeout(8000, () => { try { r.destroy(); } catch (_) {} fin(null); });
    } catch (_) { fin(null); }
  });
}
// Puxa painel+css do servidor. Valida que veio CODIGO do painel (nao o HTML da dash, que
// o worker devolve como fallback de rota nao encontrada). Falha/HTML -> null (usa o disco).
async function fetchPanelAssets() {
  const [pj, pcss] = await Promise.all([fetchText(PANEL_JS_URL), fetchText(PANEL_CSS_URL)]);
  if (!pj || pj.indexOf('__zvInstalled') < 0 || pj.indexOf('"__LIBRARY__"') < 0 || pj.indexOf('"__CSS__"') < 0) return null;
  if (!pcss || pcss.indexOf('#zv-') < 0) return null;
  return { panelRaw: pj, css: pcss };
}
function hashStr(s) { let h = 0; for (let i = 0; i < s.length; i++) { h = ((h << 5) - h + s.charCodeAt(i)) | 0; } return String(h >>> 0); }
let currentPanelHash = '';

function getJson(pathname) {
  return new Promise((res, rej) => {
    const r = http.get({ host: '127.0.0.1', port: PORT, path: pathname }, (rr) => {
      let d = ''; rr.on('data', (c) => (d += c)); rr.on('end', () => { try { res(JSON.parse(d)); } catch (e) { rej(e); } });
    });
    r.on('error', rej);
    // Sem timeout, uma conexao meia-aberta (browser em estado ruim) penduraria o watchdog
    // pra sempre e o deadline de 60s do acquirePage nunca seria reavaliado.
    r.setTimeout(5000, () => { try { r.destroy(); } catch (_) {} rej(new Error('timeout')); });
  });
}

// Corre uma promise contra um timeout; se estourar, rejeita (nao trava o loop de recuperacao).
function withTimeout(promise, ms) {
  return new Promise((resolve, reject) => {
    const t = setTimeout(() => reject(new Error('timeout')), ms);
    promise.then((v) => { clearTimeout(t); resolve(v); }, (e) => { clearTimeout(t); reject(e); });
  });
}

// Audios vao embutidos (base64, leves). Videos sao pesados: NAO embutimos nem
// servimos por HTTP (o WhatsApp bloqueia fetch a 127.0.0.1 por CSP/mixed-content).
// Em vez disso, o painel pede o video (window.__zvReq) e o injetor entrega o
// base64 via CDP na hora do clique, chamando window.__zvDoSend na pagina (WPP envia).
async function buildLibrary(remote) {
  const lib = JSON.parse(fs.readFileSync(path.join(DIR, 'library.json'), 'utf8'));
  // Mensagens e funis: se a AXION mandou config, ela manda (o Diretor edita na dash);
  // senao, cai no library.json local.
  const rMsgs = remote && Array.isArray(remote.messages) && remote.messages.length ? remote.messages : (lib.messages || []);
  const messages = rMsgs.map((it) => ({ id: it.id, stage: it.stage || 'MSG', label: it.label, kind: 'text', text: it.text || '', grp: it.grp || '' }));
  const sequences = remote && Array.isArray(remote.sequences) && remote.sequences.length ? remote.sequences : (lib.sequences || []);
  const triggers = remote && Array.isArray(remote.triggers) ? remote.triggers : [];
  // Midia unificada (audio/video/imagem/documento). O painel agrupa por tipo.
  // Online: tudo vem da dash (R2) — funil campeao + midia do Diretor, editaveis.
  // Offline: cai no funil local (library.json) pra nao ficar sem soundboard.
  const media = [];
  const remoteMedia = remote && Array.isArray(remote.media) ? remote.media : [];
  if (remoteMedia.length) {
    for (const m of remoteMedia) {
      if (!m || !m.key) continue;
      const url = MEDIA_BASE + '/' + m.key;
      // video pesado: NAO embute; painel pede via __zvReq e injetor entrega base64 no clique.
      if (m.kind === 'video') {
        var vit = { id: m.id, kind: 'video', label: m.label || 'Video', caption: m.caption || '', mediaUrl: url, grp: m.grp || '' };
        if (m.posterKey) { const pbuf = await fetchBytes(MEDIA_BASE + '/' + m.posterKey); if (pbuf) vit.posterUri = 'data:image/jpeg;base64,' + pbuf.toString('base64'); }
        media.push(vit); continue;
      }
      const buf = await fetchBytes(url);
      if (!buf) continue;
      const dataUri = 'data:' + (m.mime || (m.kind === 'image' ? 'image/jpeg' : m.kind === 'document' ? 'application/pdf' : 'audio/ogg')) + ';base64,' + buf.toString('base64');
      if (m.kind === 'image') media.push({ id: m.id, kind: 'image', label: m.label || 'Imagem', caption: m.caption || '', dataUri, grp: m.grp || '' });
      else if (m.kind === 'document') media.push({ id: m.id, kind: 'document', label: m.label || 'Documento', mime: m.mime || 'application/pdf', dataUri, grp: m.grp || '' });
      else media.push({ id: m.id, kind: 'audio', label: m.label || 'Audio', dataUri, durMs: Math.min(7000, Math.max(1800, Math.round(buf.length / 1024) * 6)), grp: m.grp || '' });
    }
  } else {
    // Fallback offline (sem config na nuvem). O instalador do vendedor nao traz esses
    // arquivos pesados; se faltarem, ignora (online ele pega o funil real do R2).
    (lib.funnel || []).forEach((it) => {
      try {
        media.push({ id: it.id, stage: it.stage, kind: 'audio', label: it.label, desc: it.desc || '',
          dataUri: 'data:audio/ogg;base64,' + fs.readFileSync(path.join(DIR, it.file)).toString('base64'),
          durMs: Math.min(7000, Math.max(1800, (it.sizeKB || 300) * 6)) });
      } catch (_) {}
    });
    (lib.social || []).forEach((it) => {
      try { if (fs.existsSync(path.join(DIR, it.file))) media.push({ id: it.id, stage: it.stage, kind: it.kind || 'video', label: it.label, caption: it.caption || '', file: String(it.file).replace(/\\/g, '/') }); } catch (_) {}
    });
  }
  return { messages, sequences, media, triggers, funnel: [], social: [] };
}

let currentCfgStamp = 0; // updated_at da config ja aplicada no painel (pra detectar mudancas)
async function buildBundle() {
  const remote = await fetchRemoteConfig();
  if (remote && remote.updated_at) currentCfgStamp = remote.updated_at;
  if (remote && ((remote.messages && remote.messages.length) || (remote.sequences && remote.sequences.length))) console.log('[zv] Config carregada da AXION (mensagens/funis da dash).');
  else console.log('[zv] Sem config na AXION ainda; usando o funil local (library.json).');
  const wajs = fs.readFileSync(path.join(DIR, 'vendor', 'wppconnect-wa.js'), 'utf8');
  // Painel + css: tenta do servidor (auto-update, sem rebaixar). Se nao vier, usa o do disco.
  let css, panelRaw, src = 'disco';
  const rp = await fetchPanelAssets();
  if (rp) { panelRaw = rp.panelRaw; css = rp.css; src = 'servidor'; }
  else { panelRaw = fs.readFileSync(path.join(DIR, 'panel-inject.js'), 'utf8'); css = fs.readFileSync(path.join(DIR, 'panel.css'), 'utf8'); }
  currentPanelHash = hashStr(panelRaw + '|' + css);
  console.log('[zv] Painel carregado do ' + src + '.');
  // replace por FUNCAO (imune a sequencias $ nos dados, ex: "R$497")
  const libJson = JSON.stringify(await buildLibrary(remote));
  const panel = panelRaw.replace('"__LIBRARY__"', () => libJson)
               .replace('"__CSS__"', () => JSON.stringify(css));
  return { wajs, panel };
}

class CDP {
  constructor(ws) {
    this.ws = ws; this.id = 0; this.cbs = {}; this.onEvent = null;
    ws.addEventListener('message', (e) => {
      let m; try { m = JSON.parse(e.data); } catch (_) { return; }
      if (m.id && this.cbs[m.id]) { this.cbs[m.id](m); delete this.cbs[m.id]; }
      else if (m.method && this.onEvent) this.onEvent(m);
    });
  }
  send(method, params) {
    return new Promise((res) => { const id = ++this.id; this.cbs[id] = res; this.ws.send(JSON.stringify({ id, method, params: params || {} })); });
  }
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function listTargets() {
  try { const t = await getJson('/json'); return Array.isArray(t) ? t : []; }
  catch (_) { return []; }
}
function isWhatsAppPage(t) { return t && t.type === 'page' && /web\.whatsapp\.com/i.test(t.url || ''); }
// Pagina do PROPRIO WhatsApp travada na tela de erro/cacto. So consideramos "cacto do
// WhatsApp" quando o TITULO menciona whatsapp — uma URL chrome-error:// sozinha NAO prova
// identidade nenhuma (poderia ser a pagina de erro de outro app WebView2 na mesma porta,
// e a gente acabaria sequestrando o app errado ao navegar pra web.whatsapp.com).
function isCrashedWhatsApp(t) {
  if (!t || t.type !== 'page') return false;
  const u = (t.url || '').toLowerCase(), ti = (t.title || '').toLowerCase();
  if (u.indexOf('web.whatsapp.com') >= 0) return false; // ja carregou; nunca recarregar por engano
  return ti.indexOf('whatsapp') >= 0;
}

// Recupera o WhatsApp quando ele abre na tela de erro (cacto): navega o proprio alvo de
// volta pra web.whatsapp.com via CDP, sem o usuario clicar em nada. Tudo com timeout: um
// renderer travado pode aceitar o WebSocket e nunca responder, o que penduraria o loop.
async function reloadCrashed(t) {
  let ws2 = null;
  try {
    await withTimeout((async () => {
      ws2 = new WebSocket(t.webSocketDebuggerUrl);
      await new Promise((res, rej) => { ws2.addEventListener('open', res, { once: true }); ws2.addEventListener('error', rej, { once: true }); });
      const c2 = new CDP(ws2);
      await c2.send('Page.enable');
      await c2.send('Page.navigate', { url: 'https://web.whatsapp.com/' });
    })(), 5000);
    return true;
  } catch (_) { return false; }
  finally { try { if (ws2) ws2.close(); } catch (_) {} }
}

// Procura a pagina do WhatsApp com paciencia (ate ~60s). O app da Store demora pra
// carregar web.whatsapp.com; e se ele abrir na tela de erro (cacto), a gente manda
// recarregar sozinho. So desiste depois de tentar de verdade — nada de loop de 3s.
async function acquirePage() {
  const deadline = Date.now() + 60000;
  let saidBooting = false, saidBusy = false, tries = 0;
  while (Date.now() < deadline) {
    const targets = await listTargets();
    const wa = targets.find(isWhatsAppPage);
    if (wa && wa.webSocketDebuggerUrl) return wa;
    // Achou o WhatsApp, mas sem porta de debug livre: outra sessao (outra janela preta do
    // Sale Chat, ou DevTools) ja esta conectada. Nao mexe; avisa uma vez e espera liberar.
    if (wa && !wa.webSocketDebuggerUrl) {
      if (!saidBusy) { saidBusy = true; console.log('[zv] O WhatsApp ja tem uma sessao do Sale Chat conectada. Feche as OUTRAS janelas pretas e deixe so uma aberta.'); }
      await sleep(3000); tries++; continue;
    }
    const crashed = targets.find(isCrashedWhatsApp);
    if (crashed && crashed.webSocketDebuggerUrl && (tries % 6) === 0) {
      console.log('[zv] WhatsApp esta numa tela de erro; mandando recarregar sozinho...');
      await reloadCrashed(crashed);
    } else if (!saidBooting) {
      saidBooting = true;
      const seen = targets.filter((t) => t.type === 'page').map((t) => t.url || '(sem url)');
      console.log('[zv] Porta ' + PORT + ' respondeu; esperando o WhatsApp carregar...' + (seen.length ? ' (paginas: ' + seen.join(' | ') + ')' : ' (nenhuma pagina ainda)'));
    }
    tries++;
    await sleep(1500);
  }
  return null;
}

async function run() {
  const page = await acquirePage();
  if (!page) {
    console.log('[zv] Nao achei o WhatsApp na porta ' + PORT + ' depois de 1 min.');
    console.log('[zv] Feche o WhatsApp POR COMPLETO (inclusive o icone perto do relogio) e rode o start de novo.');
    process.exit(2);
  }
  console.log('[zv] Pagina encontrada:', page.title);
  const _bundle = await buildBundle();
  const wajs = _bundle.wajs;
  let panel = _bundle.panel;
  let panelScriptId = null;

  const ws = new WebSocket(page.webSocketDebuggerUrl);
  await new Promise((res, rej) => { ws.addEventListener('open', res, { once: true }); ws.addEventListener('error', rej, { once: true }); });
  const cdp = new CDP(ws);
  await cdp.send('Runtime.enable');
  await cdp.send('Page.enable');

  // Helper: Runtime.evaluate usa o campo "expression"; o resultado vem em result.result.value
  async function evaluate(expression, byValue) {
    const r = await cdp.send('Runtime.evaluate', { expression, returnByValue: !!byValue, awaitPromise: false });
    return r.result || {};
  }
  const valOf = (x) => (x.result ? x.result.value : undefined);

  // Re-injeta automaticamente em cada carregamento/reload da pagina (roda no document-start)
  await cdp.send('Page.addScriptToEvaluateOnNewDocument', { source: wajs });
  { const r = await cdp.send('Page.addScriptToEvaluateOnNewDocument', { source: panel }); panelScriptId = r && r.result && r.result.identifier; }

  async function injectNow() {
    const hasWpp = valOf(await evaluate('!!window.WPP', true));
    if (!hasWpp) await evaluate(wajs);
    await evaluate(panel);
    const ok = valOf(await evaluate('!!window.__zvInstalled', true));
    console.log('[zv] Painel injetado:', ok === true);
  }
  await injectNow();

  // Bomba de video: o painel pede (window.__zvReq), o injetor le o arquivo e
  // entrega o base64 na pagina chamando window.__zvDoSend (WPP envia). Evita
  // fetch bloqueado por CSP e nao embute video pesado na injecao inicial.
  let lastReqId = null;
  async function pumpVideo() {
    try {
      const raw = valOf(await evaluate('window.__zvReq ? JSON.stringify(window.__zvReq) : ""', true));
      if (raw) {
        let req = null; try { req = JSON.parse(raw); } catch (_) {}
        if (req && req.id !== lastReqId) {
          lastReqId = req.id;
          await evaluate('window.__zvReq = null;');
          try {
            let dataUri;
            if (req.url) {
              const buf = await fetchBytes(req.url);
              if (!buf) throw new Error('nao consegui baixar o video da nuvem');
              dataUri = 'data:video/mp4;base64,' + buf.toString('base64');
            } else {
              const full = path.join(DIR, req.file || '');
              if (!full.startsWith(DIR) || !fs.existsSync(full)) throw new Error('arquivo nao encontrado: ' + req.file);
              dataUri = 'data:video/mp4;base64,' + fs.readFileSync(full).toString('base64');
            }
            await evaluate('window.__zvDoSend(' + JSON.stringify(dataUri) + ',' + JSON.stringify(req.caption || '') + ',' + JSON.stringify(req.id) + ')');
          } catch (e) {
            await evaluate('window.__zvRes = {id:' + JSON.stringify(req.id) + ',ok:false,err:' + JSON.stringify(String(e.message || e)) + '}');
          }
        }
      }
    } catch (_) {}
    setTimeout(pumpVideo, 700);
  }
  pumpVideo();

  // Bomba de PREVIA de video: o painel pede (window.__zvPrevReq) pra ver o video antes
  // de enviar; o injetor baixa da nuvem e devolve o base64 (window.__zvPrevRes). Nao envia.
  let lastPrevId = null;
  async function pumpPreview() {
    try {
      const raw = valOf(await evaluate('window.__zvPrevReq ? JSON.stringify(window.__zvPrevReq) : ""', true));
      if (raw) {
        let req = null; try { req = JSON.parse(raw); } catch (_) {}
        if (req && req.id !== lastPrevId) {
          lastPrevId = req.id;
          await evaluate('window.__zvPrevReq = null;');
          try {
            if (!req.url) throw new Error('sem url');
            const buf = await fetchBytes(req.url);
            if (!buf) throw new Error('nao consegui baixar');
            const dataUri = 'data:' + (req.mime || 'video/mp4') + ';base64,' + buf.toString('base64');
            await evaluate('window.__zvPrevRes = {id:' + JSON.stringify(req.id) + ',ok:true,dataUri:' + JSON.stringify(dataUri) + '}');
          } catch (e) {
            await evaluate('window.__zvPrevRes = {id:' + JSON.stringify(req.id) + ',ok:false,err:' + JSON.stringify(String(e.message || e)) + '}');
          }
        }
      }
    } catch (_) {}
    setTimeout(pumpPreview, 700);
  }
  pumpPreview();

  // Atualizacao ao vivo: checa a config da dash a cada 20s. Se o Diretor editou
  // (updated_at mudou), reconstroi a biblioteca e empurra pro painel (window.__zvUpdate),
  // sem precisar reabrir o WhatsApp nem rodar o start.bat de novo.
  async function pollConfig() {
    try {
      const remote = await fetchRemoteConfig();
      if (remote && remote.updated_at && remote.updated_at !== currentCfgStamp) {
        currentCfgStamp = remote.updated_at;
        const libJson = JSON.stringify(await buildLibrary(remote));
        await evaluate('window.__zvUpdate && window.__zvUpdate(' + libJson + ')');
        console.log('[zv] Config atualizada na dash; painel recarregado ao vivo.');
      }
    } catch (_) {}
    setTimeout(pollConfig, 20000);
  }
  setTimeout(pollConfig, 20000);

  // Auto-update do PAINEL: a cada 60s checa se o codigo do painel mudou no servidor. Se mudou,
  // reconstroi o bundle e re-injeta ao vivo (o painel se limpa e sobe a versao nova). O
  // atendente ganha as melhorias sem rebaixar nada. Falha/offline -> mantem o painel atual.
  async function pollPanel() {
    try {
      const rp = await fetchPanelAssets();
      if (rp) {
        const h = hashStr(rp.panelRaw + '|' + rp.css);
        if (currentPanelHash && h !== currentPanelHash) {
          const rebuilt = await buildBundle();   // usa a versao nova do servidor; atualiza currentPanelHash
          const okNew = rebuilt && rebuilt.panel && rebuilt.panel.indexOf('__zvInstalled') >= 0;
          if (okNew) {
            panel = rebuilt.panel;
            try { if (panelScriptId) await cdp.send('Page.removeScriptToEvaluateOnNewDocument', { identifier: panelScriptId }); } catch (_) {}
            { const r = await cdp.send('Page.addScriptToEvaluateOnNewDocument', { source: panel }); panelScriptId = r && r.result && r.result.identifier; }
            await evaluate(panel);
            console.log('[zv] Painel atualizado sozinho (nova versao do servidor).');
          }
        }
      }
    } catch (_) {}
    setTimeout(pollPanel, 60000);
  }
  setTimeout(pollPanel, 60000);

  cdp.onEvent = (m) => { if (m.method === 'Page.loadEventFired') setTimeout(injectNow, 1500); };
  ws.addEventListener('close', () => { console.log('[zv] Conexao caiu. Rode de novo (o app reiniciou?).'); process.exit(0); });
  console.log('[zv] Rodando. Deixe esta janela aberta. O painel esta dentro do WhatsApp.');
}

run().catch((e) => { console.log('[zv] Erro:', e && e.message || e); process.exit(1); });
